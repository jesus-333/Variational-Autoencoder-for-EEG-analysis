Questi risultati sono stati ottenuti dividendo il training set in train_set e validation_set.
Il parametro usato è stato dentro config_dataset è stato percentage_split_train_validation = 0.9 con il seed uguale a 42
